<?php  

/* Template Name: check-Page */

?>
<?php
$thestime = $_POST['timee'];
$datetime_from = date("H:i", strtotime("-45 minutes", strtotime($thestime)));
echo $datetime_from;

?>