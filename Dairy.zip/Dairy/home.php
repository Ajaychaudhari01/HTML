<?php  
/* Template Name: Home-Page */


?>
<?php
session_start();
$_SESSION["id"] = 1;

?>
<!doctype html>
<html lang="en" class="m-0">
  <head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="megakit,business,company,agency,multipurpose,modern,bootstrap4">
  
  <meta name="author" content="themefisher.com">

  <title>Template</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,800,900" rel="stylesheet">

  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="<?php bloginfo('template_directory')?>/css/style.css">
  <style type="text/css">
div.menu-menu-1-container ul
{
list-style:none;
}
</style>
<?php wp_head();?>
</head>
<body>
    <header>
        <div class="container">
            <a href="#">Booking System Diary functions</a>
        </div>
    </header>

    <section class="event_home_page">
        <div class="container">
            <div class="home_page_content">
                <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">What is Lorem Ipsum?</h2>
                <p class="font-weight-regular mb-3 mb-md-5">Lorem Ipsum is simply dummy text of the printing and typesetting
                    industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an
                    unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived
                    not only five centuries, but also the leap into electronic typesetting, remaining essentially
                    unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem
                    Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including
                    versions of Lorem Ipsum.</p>
                <a class="btn_design btn" href="../wordpress/event-2/">Book Your Event</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p class="text-center">© Copyright 2022 Booking System Diary functions</p>
        </div>
    </footer>



    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

</body>