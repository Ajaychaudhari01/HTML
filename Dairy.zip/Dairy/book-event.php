<?php
/* Template Name: Event */
?>

        
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dairy</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="<?php bloginfo(
    "template_directory"
    ); ?>/css/style.css">
    
</head>
<body id="bookEvent">
  <?php
    if (isset($_POST['submit'])) {

    }
  ?>

  <div class="cstm_loader" id="Loader">
    <div class="spinner-border text-light" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>
    <header>
        <div class="container">
            <a href="#">Booking System Diary functions <span class="countdown bg-danger text-light"></span>
            </a>
        </div>
    </header>
    
    
    <div id="Step1" class="comm-padding">
      <div class="container">
            
        <p>Plsese Selected Your event</p>
        <div class="quantity-sec">
            <div id="field1">Quantity
                <button type="button" id="sub" class="sub">-</button>
                <input type="number" id="QtyValue" value="1" min="1" max="10" />
                <button type="button" id="add" class="add">+</button>
            </div>
        </div>
        <div class="available_Book_type_sec">
            <!-- <button type="button" id="getBookingDates" class="btn btn-info">Info</button> -->
            <div class="available_Book_type">
                <!--available_Book_type will be display here !!!! -->
                
            </div>
        </div>
        <div class="select-a-date-sec mt-5">
            <input class="flatpickr" placeholder="Plase select A date">
            <p id="fromTodate" class="d-lg-none">You Have Selected Date - <small id="fromTime"></small> To <small id="toTime"></small></p>
            <p class="date_selection_message"></p>
        </div>
        <div id="ErrorMsg">
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <span id="getDateErro"></span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        </div>

        <button id="getDates" class="btn_design btn">Getslots</button>   
      </div>
    </div>
    
    <!-- action="../checkout/" -->
    <div id="Step2">
      <form name="myForm"  enctype="multipart/form-data" method="post" id="myForm">
          <section class="event_booking_page">
              <div class="container">
                
                <div id="ErrorMsgs">
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <span id="getDateError"></span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    </div>
                  
                   <div id="dateSelectionError">
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <span id="dateSelectionErr"></span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    </div>
                  <div class="cal-modal">
                      <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Select a date and time for your event</h2>
                      <p class="date_selection_message"></p>
                      <div id="calendar">
                          <div class="placeholder"> </div>
                      </div>
                  </div>
                  <div class="available_time_slot" id="DayDisplay">
                      <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Available times for <span id="selectedDtaes" class="text-danger"></span>  at your event</h2>
                      
                      <div class="select_time_slot" id="hello">
                          <!-- time slot will be display here !!!! -->
                      </div>
                      <div class="time_remember" id="Remember">
                          <p class="m-0"><b>Remember:</b> You will need to arrive no later than <span id="arrivalTim"  hidden="hidden"  name="arrivalTim">10:00</span><span id="arrivalTimer" name="dateandTime" class="font-weight-bold">00:00</span></p>
                      </div>
                  </div>
                  
                  
                  
                  <input type="text"   hidden="hidden" id="dateandTime" name="dateandTime">
                  <input type="text"   hidden="hidden" id="selectedDates" name="selectedDates">
                  <input type="text"   hidden="hidden" id="selectedQty" name="selectedQty">
                  
                  <input type="text"   hidden="hidden" id="selectdBookType" name="selectdBookType">
                  <input type="text"   hidden="hidden" id="arrVal" name="arrVal">
                  <input type="text"   hidden="hidden" id="dateWIthtime" name="dateWIthtime">
            <div class="text-right d-flex justify-content-between flex-wrap mt-2">
              <button class="btn_design back_btn btn mr-3" type="button" onclick="BackStep1()">Back</button>
              <button type="button" class="btn_design btn ml-5" name="submit" id="BookNOW">Proceed</button>
            </div>
              </div>
          </section>
      </form>

    </div>



<!-- ===============================   checkout section            ============================================== -->

    <section class="checkout_page" id="Step3">
        <div class="container">
            <h2 class="mt-0 mb-2 mb-md-4 font-weight-bold">CHECKOUT</h2>
            <div class="booking_details">
                <h3 class="mt-0 mb-2">YOUR BOOKING FOR <span id="checkoutDate"></span> AT STOCKHOLM</h3>
                <P class="mt-0 mb-2 mb-md-3">Check-in time: <span class="chekoutDateWIthtime"></span></P>
                <ul class="booking_details_inr">
                    <li class="booking_title">
                        <h3>2 FLIGHT PACKAGE – <span id="flightType"></span></h3>
                        <p><b>Location:</b> Stockholm</p>
                    </li>
                    <li>
                        <p><b>Time: <span class="chekOutTime"></span></b></p>
                    </li>
                    <li class="booking_user">
                        <p><b>1</b></p>
                    </li>
                    <li>
                        <p><b>Quantity: <span class="checkoutQty"></span></b></p>
                    </li>
                    <li>
                        <p><b>Price: <span>695.00Kr</span></b></p>
                    </li>
                </ul>
                <div class="time_remaining d-sm-flex justify-content-between align-items-center mt-3 mt-md-4 mb-1 mb-sm-2">
                    <p class="mb-2 mb-sm-0">Time remaining to complete this booking: <span id="demo">10:00</span> </p>
                    <h3 class="m-0">Total: 695.00Kr</h3>
                </div>
            </div>
          <form class="contact_form" action="../payment-2/" method="post" id="CheckoutForm">
            <div class="payment_details">
                <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">PLEASE ENTER YOUR BILLING AND PAYMENT DETAILS</h2>
                <div class="row">
                    <div class="col-lg-6">
                        <h3 class="mt-0 mb-3">BILLING DETAILS</h3>
                            <div class="form-group">
                                <label>First name</label>
                                <input type="text" class="form-control" id="" name="fname">
                            </div>
                            <div class="form-group">
                                <label>Last name</label>
                                <input type="text" class="form-control" id="" name="lname">
                            </div>
                            <div class="form-group">
                                <label>Telephone</label>
                                <input type="number" class="form-control" id="" name="telNumber">
                            </div>
                            <input type="text" class="form-control" id="sessionIds" name="sessionIds" hidden>

                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" id="" name="email">
                            </div>
                    </div>
                    <div class="col-lg-6">
                            <div class="form-group form-check">
                              <div class="checkbox-wrapper">
                                <input type="checkbox" class="form-check-input" id="exampleCheck1" name="confirmation">
                                <label class="form-check-label" for="exampleCheck1">I understand that I need to arrive
                                    by 16:45 in order to take part in my first activity</label>
                                </div>
                            </div>
                            <div class="form-group form-check">
                              <div class="checkbox-wrapper">
                                <input type="checkbox" class="form-check-input" id="exampleCheck2" name="conditions">
                                <label class="form-check-label" for="exampleCheck2">I have read and agree to the <a
                                        href="#">terms and conditions</a></label>
                                </div>
                            </div>
                    </div>
                </div>
                    <div class="text-right d-flex justify-content-between mt-2">
                        <!-- <a class="btn_design back_btn btn mr-3" href="home.html">Back</a> -->
                        <button class="btn_design back_btn btn mr-3" type="button" onclick="BackStep2()">Back</button>
                        <button type="submit" class="btn_design btn ml-5" name="submit" id="CheckoutFormBtn">Payment</button>
                    </div>

               </form>

            </div>
        </div>
    </section>







    <footer>
        <div class="container">
            <p class="text-center">© Copyright 2022 Booking System Diary functions</p>
        </div>
    </footer>
    
    
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- for timer  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Validation link -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="<?php bloginfo("template_directory"); ?>/js/script.js"></script>

    
    <!-- for timer  -->
    <script>
    function BackStep1(){
      $("#Step2").hide();
      $("#Step3").hide();
      $("#Step1").show();
    }

    function BackStep2(){
      $("#Step1").hide();
      $("#Step3").hide();
      $("#Step2").show();
    }

    $(document).ready(function() {

    $("#ErrorMsgs").hide(); 
// ==============================================
//for time diffrence 
   //       var start = '15:30';
   // var end = '07:50';
   // s = start.split(':');
   // e = end.split(':');
   // min = e[1]-s[1];
   // hour_carry = 0;
   // if(min < 0){
   //     min += 60;
   //     hour_carry += 1;
   // }
   // hour = e[0]-s[0]-hour_carry;
   // min = ((min/60)*100).toString()
   // diff = hour + ":" + min.substring(0,2);
   // // alert(diff);
   // console.log(diff);


      var arr = [];
      $("#Step2").hide();
      $("#Step3").hide();
      SelectedBookingType();
      $("#getDates").on('click',function () {
        $("#Loader").show();
        let bookingintTypes= "";
        var value = $("input[type=radio][name=slot]:checked").val();
        if (value) {
          // alert('======='+value);
          bookingintTypes =value;
        }
        else {
          $("#Loader").hide();
          // alert('Nothing is selected');
        }
        let selBookingQty =  $('#QtyValue').val();
        let selBookingStartTime=$('#fromTime').text();
        $("#fromTOdate").html()
        let selBookingEndTime=$('#toTime').text();
        $("#selectdBookType").val(bookingintTypes);
        $("#flightType").text(bookingintTypes);
        $("#selectedQty").val(selBookingQty)
        $(".checkoutQty").text(selBookingQty); //3 api

        if(selBookingQty && bookingintTypes && selBookingStartTime){  
          if(selBookingEndTime){
            arr = [selBookingQty,bookingintTypes,selBookingStartTime,selBookingEndTime];
            console.log(arr);
          }
          else{
            selBookingEndTime =selBookingStartTime;
            arr = [selBookingQty,bookingintTypes,selBookingStartTime,selBookingEndTime];
            console.log(arr);
          }
        }
        else{
          $("#Loader").hide();
          $("#getDateErro").html("Please select all fields");
          $("#ErrorMsg").show();          
          return 0;
        }
        console.log(arr);
        setTimeout(() => {
          $("#Step1").hide();
          $("#Step2").show();
          $("#Loader").hide();
          CheckDate();
        });
      })
   

   //================================= create api 3 =======================================
   $("#BookNOW").on('click',function (){
    $("Step1").hide();
    $("#Step2").hide();
    $("#Loader").show();
    let selectedDateData =$("#selectedDtaes").text();
    let arrivalTimeData =$("#arrivalTimer").text();
    if (selectedDateData && arrivalTimeData){
    BookNow(); 
    $("#ErrorMsgs").hide(); 
    }
    else{
      $("#ErrorMsgs").show(); 
      $("#getDateError").html("Please select all fields");
     $("#Loader").hide();
      $("#Step2").show();
      return 0; 


    }
   })
   function BookNow() {
    timers(); //timer start
        let bookingDat=$(".chekoutDateWIthtime").text();
        let BookingQt=$(".checkoutQty").text();

        let BookingTypId =$("#flightType").text();
        console.log(BookingTypId);
        
        // let sessionId= "335137f2-e362-4aa5-ad16-03b98206j02g";
        let sessionId ="335137f2-e362-4aa5-ad16-03b98200f07f";
        // let sessionId ="cef0cbf3-6458-4f13-a418-ee4d7e";
        $("#sessionIds").val(sessionId);

    let unitCost= 5;
    let url ='http://enginetest.megafun.no/bookings/create?bookingTypeId='+BookingTypId.trim()+'&quantity='
        +BookingQt+'&bookingDate='+bookingDat+'&sessionId='+sessionId+'&unitCost='+unitCost+'&discountCode='+null+'&vouchers='+null;
        console.log(url);   
        $.ajax({
          url:url,
          type:'POST',
            success: function(data, textStatus, xhr) {
              console.log("=================>",data);
                if (xhr.status == 200) {

                $("#Step2").hide();
                $("#Step1").hide();
                $("#Step3").show();
                $("#Loader").hide();
                }
                else{
                  alert(1212);
                }
        console.log(xhr.status);
          }
        });
        
      } 




    
    //function for select a date 
    function CheckDate(){
      console.log('====',arr);
      let x =0;
      let chooseDate =0;
      $(".flatpickr-day").on('click', function(event){
        $("#Loader").show();
        x=x+1;   
        // console.log(x);       
        // $(".flatpickr-day .flatpickr-disabled").css('background-color', 'red');
        // $(".flatpickr-day .flatpickr-disabled").css('background-color', 'yellow');
        // $(this).css('background-color', '#b10794');
        chooseDate =$(this).attr('aria-label');
        var dateWithDay = $(this).attr('aria-label');
        // console.log("date picker: ", dateWithDay);
        var xy = new Date(dateWithDay);
        // console.log("now====>",xy)
        var da = 60 * 60 * 24 * 1000;
        var xy = new Date(xy.getTime() + da);
        // console.log("hgfggh====================>",xy);
        // console.log("now2====>",xy)
        var dateWIthtime=(new Date(xy).toISOString());
        // console.log("dateWIthtime====>",dateWIthtime)
        $("#dateWIthtime").val(dateWIthtime);
        $(".chekoutDateWIthtime").text(dateWIthtime);
        let aj= "T00:00:00+01:00"
        const myJSON = JSON.stringify(xy);
        let y =myJSON.slice(1,11);
        const myDate = y.concat(aj);
        // console.log("=====>>>>",myDate);
        const dates = $(this).text(); 
        $('#selectedDtaes').text(dateWithDay);   
        $("#checkoutDate").text(dateWithDay); //api 3
        $('#selectedDates').val(myDate);                   
        $('#ChoosenDate').text(dateWithDay); 
        const dd = new Date(dateWithDay);
        dateWithDay= dd.toISOString();   
        let bookingSlot=[];
        let chosednSlots = [];
        let datess = [];
        let chosednTimeSlots=[];
        let uRL ='http://enginetest.megafun.no/diary/getdates/?BookingTypeId='+arr[1]+'&Quantity='+arr[0]+'&fromDate='+arr[2]+'&toDate='+arr[3];
        console.log("diary/getdates====>",uRL);
        // let url1 = 'http://enginetest.megafun.no/diary/getdates/?BookingTypeId=2&Quantity=9&fromDate=2022-07-22T12:05:19.640Z&toDate=2022-07-29T12:05:19.640Z';
        // // console.log(uRL);
        // // console.log(uRL);
        $.ajax({
          type:'POST',
          url:uRL,
          // url:uRL,
          success:function (data) {
            $("#Loader").hide();
            console.log(data.dates);
            for(var i=0;i<data.dates.length;i++){
              bookingSlot[i] = (data.dates[i]);
            };
            var rowss = [];
            let counT = 0;

          for(var j=0;j<bookingSlot.length;j++){
                  datess[j]=(bookingSlot[j].date);
                  let date =dateWithDay;

                  // console.log("====>>>>",dateWithDay);
                  if (myDate == datess[j])
                  {
                    counT = counT+1;
                    // console.log(bookingSlot[j].bookingSlots[j].fromTime);
                    for(var k=0;k<bookingSlot[j].bookingSlots.length;k++){
                      // console .log(k);
                      // console.log(bookingSlot[j].bookingSlots[k].fromTime);
                      rowss +=  '<label class="slot"><span class="timeSlotss">'+bookingSlot[j].bookingSlots[k].fromTime+
                      '</span><input type="radio" class="SelectedBooking timeSlots"  value="' + bookingSlot[j].bookingSlots[k].fromTime +
                      '" name="slot" /></label>';
                    }
                    $('#hello').html(rowss); 
                  }
              // chosednSlots[j] =(bookingSlot[j].bookingSlots);
            }
            if(counT == 0){
              // alert("ohh!! no ! you have to selecte date between your range");
              $("#dateSelectionError").show();
              $("#dateSelectionErr").html("ohh!! no ! you have to selecte date between your range");
              $(".slot").hide();
              $("#DayDisplay").hide();
              $("#remember").hide();
            }
            else{
              $("#dateSelectionError").hide();
              $(".slot").show();
              $("#DayDisplay").show();
              $("#remember").show();
            }

              setTimeout(() => {
                SelectDate(); 
              }, 1000); 
            },
          })
        });
        
      }


      //selected booking type ==>booking Type quantity and select date started
    function SelectedBookingType() {
      $('.add').click(function () {
        if ($(this).prev().val() < 10) {
          $(this).prev().val(+$(this).prev().val() + 1);
        }
      });
      $('.sub').click(function () {
        if ($(this).next().val() > 1) {
          if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
        }
      });
      $(".flatpickr").flatpickr({
        mode: "range",
        disableMobile: "true",
        altInput: true,
        altFormat: "Y-m-d ",
        dateFormat: "Y-m-d ",
        minDate:new Date().fp_incr(0),
        onClose: function(selectedDates, dateStr, instance) {
          var dateStart = instance.formatDate(selectedDates[0], "Y-m-d");
          var dateEnd = instance.formatDate(selectedDates[1], "Y-m-d");
          $('#fromTime').text(dateStart);
          $('#toTime').text(dateEnd);
          $(".date_selection_message").html("You Have Selected Date - <small>"+dateStart.split("T18:30:00.000Z")[0]+"</small> To <small>"+dateEnd.split("T18:30:00.000Z")[0]+"</small>");
        }
      });
      var rows = [];
      $.ajax({
        type:'GET',
        url:'http://enginetest.megafun.no/bookings/getbookingtypes',
        data:{
        },
        success:function (data) {
          for(var i=0;i<data.bookingTypes.length;i++){
            rows +=  '<label class="slot"><span class="bookingType SelectedBookingType">'+data.bookingTypes[i].description+
            '</span><input type="radio" class="SelectedBooking"  value="' + data.bookingTypes[i].id +
            '" name="slot" /></label>';
          };
          $('.available_Book_type').html(rows);
        },
      })     
    }
    
      function SelectDate() {
        $(".select_time_slot .slot .timeSlotss").on('click',function () {
          let timeslots=$(this).text();
          // console.log(timeslots); 
          $("#arrivalTimer").html(timeslots);
          $(".chekOutTime").text(timeslots); //3 api
          $("#selectedDates").val(timeslots);


        });
      }
    
    });


//timer 
// ===============================
function timers() {
    $("#sessionVar").text()
    const d = new Date();
    let countDownDate = d.getTime();
    var x = setInterval(function() {
        var x= new Date().getTime();
        // change for time diffrendce
        // var now = x-1800000;
        
        var now = x-18000;
        var distance = countDownDate - now;
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
        if (distance < 0) {
            clearInterval(x);
            window.location.href = "http://localhost:7000/wordpress/event-2/";
            
            // document.getElementById("demo").innerHTML = "EXPIRED";
        }
    }, 1000);
}

// Validation 
  //====================================================================
  // Custom Email
  //====================================================================
  $.validator.addMethod("customemail", 
  function(value, element) {
      return /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value);      
  },'Please enter a valid email.');

  $("#CheckoutForm").validate({
    rules: {
      fname : {
        required: true,
        minlength: 3
      },
      lname : {
        required: true,
        minlength: 3
      },
      email: {
        required: true,
        customemail: true
      },
      telNumber: {
        required: true,
        number: true,
        minlength:10,
        maxlength:12
      },
      confirmation: {
        required: true,
      },
      conditions: {
        required: true,
      }
    },
    messages : {
      fname: {
        minlength: "Name should be at least 3 characters"
      },
      lname: {
        minlength: "Name should be at least 3 characters"
      },
      email: {
        email: "Please enter a valid email address"
      },
      telNumber: {
        number: "Please enter a valid phone number"
      }
    },
    errorPlacement: function (error, element) {
      if (element.attr("type") === "checkbox") {
        error.insertAfter($(element).parent());
      }else{
        error.insertAfter(element);
      }
    },
  });

  $('#CheckoutFormBtn').click(function()
    {
      $("#Loader").show();
      setTimeout( function() {
        if($('#CheckoutForm').valid())
        {
          $('#CheckoutFormBtn').prop('disabled', true);
          $('#CheckoutForm').submit();
        } else {
          $("#Loader").hide();
          return false;
        }
      }, 1000);      
    });
      </script>
                                        
  </body>
</html>  
                                    
                                    
