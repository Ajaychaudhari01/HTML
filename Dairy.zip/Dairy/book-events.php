<?php
/* Template Name: Event-Page */
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Dairy</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
  <link rel="stylesheet" href="<?php bloginfo(
      "template_directory"
  ); ?>/css/style.css">
  
</head>
<body id="bookEvent">
  <header>
    <div class="container">
      <a href="#">Booking System Diary functions <span class="countdown bg-danger text-light"></span>
      </a>
    </div>
  </header>

<!-- get booking type section started -->

<div class="container">
    <div class="row">
        <!-- <button type="button" id="getBookingDates" class="btn btn-info">Info</button> -->
        <div class="available_time_slot">
            <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Available Booking Type  for event </h2>
            <p class="m-0"><b>Note*:</b>  You have to select one Booking type<span class="bg-dark text-white" id="SelectedBookingType"></span></p><br>
            <div class="select_booking_type">
                <label class="slot">
                    <span><b>Single Flight</b></span>
                    <input type="radio" class="bookingType"  value="1" name="slot" />
                </label>
                <label class="slot">
                    <span><b>Double Flight</b></span>
                    <input type="radio" class="bookingType" value="2" name="slot" />
                </label>
                <label class="slot">
                    <span><b>Private Coaching</b></span>
                    <input type="radio" class="bookingType" checked value="3" name="slot" />
                </label>
            </div>
            <div class="time_remember">
            </div>
        </div>
    </div>
    <div class="row">
        <div id="field1">Quantity
            <button type="button" id="sub" class="sub">-</button>
            <input type="number" id="QtyValue" value="1" min="1" max="10" />
            <button type="button" id="add" class="add">+</button>
        </div>
    </div>
    <div class="row mt-3">
    <input class="flatpickr" placeholder="Plase select A date">
    <p>You Have Selected Date<small id="fromTime"></small> To <small id="toTime"></small></p>
    </div>
</div>
<button id="get_your_booking" class="bg-danger text-white">Clik For date </button>
<!-- get booking type section started -->


  <form name="myForm"  enctype="multipart/form-data" method="post">
    <section class="event_booking_page">
      <div class="container">
        
        <div class="cal-modal">
          <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Select a date and time for your event</h2>
          <div id="calendar">
            <div class="placeholder"> </div>
          </div>
        </div>
        <div class="available_time_slot">
          <h2 class="mt-0 mb-3 mb-md-4 font-weight-bold">Available times for <span id="selectedDtaes" class="text-danger"></span>  at your event</h2>
          
          <div class="select_time_slot" id="select_time_slot">
            <!-- time slot will be display here !!!! -->
          </div>
          <div class="time_remember">
            <p class="m-0"><b>Remember:</b> You will need to arrive no later than <span id="arrivalTime"  hidden="hidden"  name="arrivalTime">10:00</span><span id="arrivalTim" class="font-weight-bold">00:00</span></p>
          </div>
        </div>
        
        
        
        <input type="text"   hidden="hidden" id="Timerr" name="timerr">
        <input type="text"   hidden="hidden" id="selectedDates" name="selectedDates">
        
        <div class="text-right d-flex justify-content-between">
          <a class="btn_design back_btn btn mr-3" href="http://localhost/wordpress/">Back</a>
          <button type="submit" class="btn_design btn ml-5" name="submit" id="submit">Proceed</button>
        </div>
      </div>
    </section>
  </form>
  <footer>
    <div class="container">
      <p class="text-center">© Copyright 2022 Booking System Diary functions</p>
    </div>
  </footer>
  






        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
        <!-- for timer  -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="<?php bloginfo("template_directory"); ?>/js/script.js"></script>


        
  <!-- for timer  -->
  


<script>
$(document).ready(function() {
  
  getBookingDates();  //for booking dates
  
  // $("[tabindex=-1]").css("background-color", "yellow");
  $("#calendar").removeAttr("tabindex");
  $("#calendar").removeAttr("aria-current");
  CheckDate(); //for chose a particular date
  getBookingSlots(); //for selected Booking Type
  SelecteDateTimeBookingType(); //for 
  
});


function getBookingSlots() {
  $(".select_booking_type .slot .bookingType").on('click',function () {
    console.log("clicked ");
    let QtyVal= $('#QtyValue').val();
    let bookingType=$(this).val();
    if (bookingType == 1){
      $('#SelectedBookingType').text("Single Flight")
    }
    else if(bookingType == 2){
      $('#SelectedBookingType').text("Double  Flight")
    }else{
      $('#SelectedBookingType').text("Private Coaching")
    }
    
  });
}

// get booking date from Api
function getBookingDates() {
  $('#getBookingDates').on('click',function () {
    $.ajax({
      type:'GET',
      url:'http://enginetest.megafun.no/bookings/getbookingtypes/',
      // headers: {
        //     'Access-Control-Allow-Origin': 'http://enginetest.megafun.no/'
        // },
        data:{
        },
        success:function (data) {
          console.log(data);
        },
      });
      
    });
  }
  
  
  //function for select a date 
  function CheckDate(){
    let x =0;
    $(".flatpickr-day").on('click', function(event){
      x=x+1;   
      console.log(x);       
      
      $(".flatpickr-day .flatpickr-disabled").css('background-color', 'yellow');
      $(this).css('background-color', 'green');
      const dateWithDay = $(this).attr('aria-label');
      const dates = $(this).text(); 
      $('#selectedDtaes').text(dateWithDay);   
      $('#selectedDates').val(dateWithDay);                   
      $('#ChoosenDate').text(dateWithDay);     
      console.log(dateWithDay);
      
      var testArray1 = ["04:30","12:00","14:45","16:30"];
      var testArray2 = ["01:00","09:30","13:00","17:00","21:30"];
      var testArray= dates %2 == 0 ? testArray1 : testArray2    
      var rows = [];
      for(var i=0;i<testArray.length;i++){
        rows +=  '<label class="slot"><span class="timeSlots">'+testArray[i]+
        '</span><input type="radio" class="choose"  value="' +testArray[i] +
        '" name="slot" /></label>';
      };
      $('.select_time_slot').html(rows);
      setTimeout(() => {
        SelectDate(); 
      }, 1000);   
    });
    
  }
  
  
  function SelectDate() {
    $(".select_time_slot .slot .timeSlots").on('click',function () {
      let times=$(this).text();
      $("#arrivalTime").text(times);
      $("#Timerr").val(times);
      $("#ChoosenTimeSlots").text(times);
      $("#arrivalTime").css("", "red");
      
      //    alert(datess); 
    });
  }
  $(".flatpickr-next-month").on('click', function(){
    setTimeout(CheckDate, 1000);
  });
  $(".flatpickr-prev-month").on('click', function(){
    setTimeout(CheckDate, 1000);
  });
  $(document).on('click','#select_time_slot',function (e) {
    let timee = $("#arrivalTime").val();
    console.log(timee);
    $.ajax({
      type:'POST',
      url:'http://localhost/wordpress/check/',
      data:{
        timee: $("#arrivalTime").text()
      },
      success:function (data) {
        $("#arrivalTim").text(data);
        $("#arrivalTim").css('', '#e83e8c');
      },
    })
  });
  
  
  
  <!-- code for Quantity plus and minus    -->
  
  function SelecteDateTimeBookingType() {
    
    $('.add').click(function () {
      if ($(this).prev().val() < 10) {
        $(this).prev().val(+$(this).prev().val() + 1);
      }
    });
    $('.sub').click(function () {
      if ($(this).next().val() > 1) {
        if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
      }
    });
    
    $(".flatpickr").flatpickr({
      mode: "range",
      disableMobile: "true",
      altInput: true,
      altFormat: "Z",
      dateFormat: "Z",
      onClose: function(selectedDates, dateStr, instance) {
        var dateStart = instance.formatDate(selectedDates[0], "Z");
        var dateEnd = instance.formatDate(selectedDates[1], "Z");
        $('#fromTime').text(dateStart);
        $('#toTime').text(dateEnd);
        console.log(dateStart);
        console.log(dateEnd);
      }
    });
  }
  </script>


<script>

$(document).ready(function() {
  $('#get_your_booking').on('click',function () {
    let selBookingType = $('#SelectedBookingType').text();
    let selBookingQty =  $('#QtyValue').val();
    let selBookingStartTime = $('#fromTime').text();
    console.log(selBookingType);
    let selBookingEndTime = $('#toTime').text();  
    $.ajax({
      type:'GET',
      url:'http://enginetest.megafun.no/bookings/getbookingtypes',
      data:{
      },
      success:function (data) {
        console.log(data.bookingTypes[0].id);
      },
    })      
  })
  

  $('#submit').on('click',function () {
    alert(32);
    $.ajax({
        type:'POST',
        url:'http://enginetest.megafun.no/bookings/create/',
        data:{
            
            bookingTypeId:$('#BookingType').text(),
            quantity:$('#BookingQty').text(),
            bookingDate:$('#BookingDate').text(),
            sessionId:"string"
            // "bookingTypeId": 1,
            // "quantity": 1,
            // "bookingDate": "2022-07-25T04:23:59.317Z",
            // "sessionId": "john",
            // "unitCost": 0,
        },
        success:function (data) {
            console.log(data)
        }
    });
    
});  
  
})
</script>

  </body>
  </html>  
  
  